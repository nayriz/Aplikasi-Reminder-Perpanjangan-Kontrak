<div class="row">
            <div class="col-xl-12">
                <div class="card card-shadow mb-4">
                    <div class="card-header border-0">
                        <div class="custom-title-wrap bar-primary">
                            <!-- <div class="custom-title">Data Bangunan</div> -->
                        </div>
                    </div>
                    <div class="card-body- pt-3 pb-4">
                        <center>
                            <img src="assets/img/cropped-logo.png"><br>
                            <h3 style="margin-top: 30px" class="text-black">BIRO ADMINISTRASI SETDA</h3>
                            <h3>PROVINSI SULAWESI SELATAN</h3>
                        </center>
                    </div>
                </div>
            </div>
        </div>