<?php
session_start();
include('../koneksi.php');
$Id=isset($_POST['id'])?htmlspecialchars($_POST['id']):'';
$berkas=isset($_POST['berkas'])?htmlspecialchars($_POST['berkas']):'';
$st=isset($_GET['st'])?htmlspecialchars($_GET['st']):'';
$hasil=isset($_POST['hasil'])?htmlspecialchars($_POST['hasil']):'';
$perilaku=isset($_POST['perilaku'])?htmlspecialchars($_POST['perilaku']):'';
$kehadiran=isset($_POST['kehadiran'])?htmlspecialchars($_POST['kehadiran']):'';
$kerjasama=isset($_POST['kerjasama'])?htmlspecialchars($_POST['kerjasama']):'';
$komitmen=isset($_POST['komitmen'])?htmlspecialchars($_POST['komitmen']):'';
$aksi=$_GET['act'];
$tempat=$_GET['mod'];
$user=$_SESSION['penilai'];
$data = mysqli_fetch_assoc(mysqli_query($koneksi, "select * from tbpenilai where usernamepenilai = '$user'"));
$penilai=$data['idpenilai'];


if ($aksi == 'simpan' && $st == ''){
    $berkas=upload();
            if (!$berkas) {
        exit();
    }
    $sql=mysqli_query($koneksi, "INSERT INTO tbpenilaian VALUES('','$Id','','$berkas','','','','','','','')");
}
if ($aksi == 'simpan' && $st == '1'){
    $nhasil=$hasil*30/100;
    $nperilaku=$perilaku*30/100;
    $nkehadiran=$kehadiran*20/100;
    $nkerjasama=$kerjasama*10/100;
    $nkomitmen=$komitmen*10/100;
    $final=$nhasil+$nperilaku+$nkehadiran+$nkerjasama+$nkomitmen;
    if ($final > 75) {
        $status="Perpanjang";
    }else{
        $status="Putus";
    }
    $sql=mysqli_query($koneksi, "UPDATE tbpenilaian SET idpenilai='$penilai', hasil='$hasil',perilaku='$perilaku',kehadiran='$kehadiran', kerjasama='$kerjasama', komitmen='$komitmen',nilai='$final',status='$status' WHERE idpenilaian='$Id'");
}

if ($aksi == 'hapus'){
    $sql=mysqli_query($koneksi, "DELETE FROM tbpenilai WHERE idpenilai='$Id'");

}
if($sql){
    echo"
			<script>
			alert('Data Berhasil Di$aksi');
			document.location.href='../index.php?mod=$tempat';
			</script>";
}
else{
    echo"
			<script>
			alert('Data Gagal Di$aksi')
			// document.location.href='../index.php?mod=$tempat';
			</script>";
}

function upload(){
    global $koneksi;
    $namafile=$_FILES['berkas']['name'];
    $ukaranfile=$_FILES['berkas']['size'];
    $error=$_FILES['berkas']['error'];
    $tmpname=$_FILES['berkas']['tmp_name'];

        // if($error===4){
        //  echo "<script>
        //  alert('Pilih Gambar');
        //  window.history.back();
        //  </script>
        //  ";
        //  return false;
        // }

    $ekstensiboleh=['pdf'];
    $ekstensigambar=explode('.', $namafile);
    $ekstensigambar=strtolower(end($ekstensigambar));

        if(!in_array($ekstensigambar, $ekstensiboleh)){
         echo "<script>
         alert('Bukan File PDF');
         window.history.back();
         </script>
         ";
         return false;
        }
        if( $ukaranfile > 500000 ){
         echo "<script>
         alert('File Terlalu Besar');
         window.history.back();
         </script>
         ";
         return false;
        }

        
    $namafilebaru=uniqid();
    $namafilebaru.='.';
    $namafilebaru.=$ekstensigambar;
    move_uploaded_file($tmpname, 'file/'. $namafilebaru);
    return $namafilebaru;
}

?>